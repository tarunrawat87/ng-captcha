import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  private fontStyle="Comic Sans MS";
  private captchaHeight='250px';
  private captchaWidth='350px';
  private captchaColor="blue"
  constructor() { }


  ngOnInit() {
  }
  captchaHandler($event){
    console.log($event);;
  }
}
